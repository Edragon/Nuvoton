var group___d_a_p___config___initialization__gr =
[
    [ "DAP_SETUP", "group___d_a_p___config___initialization__gr.html#ga18407e5070a3aad09ba3773acffb05cf", null ],
    [ "RESET_TARGET", "group___d_a_p___config___initialization__gr.html#gac9d308f719319dd892cc8be7459c83f0", null ]
];