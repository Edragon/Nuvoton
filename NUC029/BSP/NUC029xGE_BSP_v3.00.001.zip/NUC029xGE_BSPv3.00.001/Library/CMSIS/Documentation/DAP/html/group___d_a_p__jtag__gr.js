var group___d_a_p__jtag__gr =
[
    [ "DAP_JTAG_Sequence", "group___d_a_p___j_t_a_g___sequence.html", null ],
    [ "DAP_JTAG_Configure", "group___d_a_p___j_t_a_g___configure.html", null ],
    [ "DAP_JTAG_IDCODE", "group___d_a_p__jtag__idcode.html", null ]
];