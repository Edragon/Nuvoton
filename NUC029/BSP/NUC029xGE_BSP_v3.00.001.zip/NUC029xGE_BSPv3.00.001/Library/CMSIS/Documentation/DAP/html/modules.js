var modules =
[
    [ "Firmware Configuration", "group___d_a_p___config__gr.html", "group___d_a_p___config__gr" ],
    [ "Connect SWO Trace", "group___d_a_p___u_s_a_r_t__gr.html", null ],
    [ "Validate Debug Unit", "group___d_a_p___validate__gr.html", null ],
    [ "CMSIS-DAP Commands", "group___d_a_p___commands__gr.html", "group___d_a_p___commands__gr" ],
    [ "CMSIS-DAP Vendor Commands", "group___d_a_p___vendor__gr.html", null ]
];